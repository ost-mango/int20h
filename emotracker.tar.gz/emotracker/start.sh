java -jar int20h-web-0.0.1-SNAPSHOT.jar > int20hBackend.log  2>&1 &
cd ui
npm install &
wait;
npm start > ../int20hFrontend.log  2>&1 &
