export const Emotion = Object.freeze({
    SADNESS: "SADNESS",
    NEUTRAL: "NEUTRAL",
    DISGUST: "DISGUST",
    ANGER: "ANGER",
    SURPRISE: "SURPRISE",
    FEAR: "FEAR",
    HAPPINESS: "HAPPINESS"
});