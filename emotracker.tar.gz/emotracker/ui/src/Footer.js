import React, {Component} from 'react';

class Footer extends Component {
    render() {
        return (
            <div>
                <footer className="sticky-footer footer">
                    <div className="container">
                        <div className="text-center">
                            <h6>Created by mAngo team</h6>
                        </div>
                    </div>
                </footer>
            </div>
        );
    }
}

export default Footer;